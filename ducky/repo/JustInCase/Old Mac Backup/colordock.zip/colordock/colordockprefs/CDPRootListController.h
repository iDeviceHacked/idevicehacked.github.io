#import <Preferences/PSListController.h>

@interface CDPRootListController : PSListController

@end
