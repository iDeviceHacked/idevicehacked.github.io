#import <Preferences/PSListController.h>

@interface DTTRootListController : PSListController

@end

@interface DTCRootListController : PSListController

@end
