@interface PostsViewController : UIViewController

- (instancetype)initWithSubreddit:(NSString *)subreddit title:(NSString *)title;

@end
