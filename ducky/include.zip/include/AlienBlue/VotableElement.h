@interface VotableElement : NSObject

@end
